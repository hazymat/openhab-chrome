# openhab-chrome
- A simple extension that allows users to control OpenHAB from a popup within Chrome
- This extension is in its infancy and currently does NOT support authentication, suggestions welcome
